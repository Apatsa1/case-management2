<nav class='navbar navbar-inverse' style='background-color: red;'>
		
			<div class='container-fluid'>
			
				<div class='navbar-header'>
			
					<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#MyNavbar'>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
					</button>
				</div>
				<div class='collapse navbar-collapse' id='MyNavbar'>
					<ul class='nav navbar-nav navbar-right'>
						<li><a href='#'>Lodge Complaint</a></li>
						<li><a href='#'>Contact Us</a></li>
						<li><a href='#'>Vacancies</a></li>
						<li><a href='#'>FAQ</a></li>
						<li><a href='#'>Intranet</a></li>
					</ul>
				</div>
			
			</div>
		
		</nav>