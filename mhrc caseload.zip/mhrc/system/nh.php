<?php
	$name='felix';
	$dbc=mysqli_connect("localhost", "root","","masterdatabase") or die("Host Unreachable");
	$query="INSERT INTO personal VALUES('james')";
		$result=mysqli_query($dbc, $query);
		if($result){
		echo 'bingoo';
		}else{
		echo 'eeeh, mbola';
		}
?>