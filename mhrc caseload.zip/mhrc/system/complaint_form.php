<!DOCTYPE html>
<?php session_start(); ?>
<html lang='en'>

<?php include"header.php"; ?>
	<br/><br/>
	<div class="container" role="main" >
      <div class="row">
    <form action='complaint_view.php' method='POST' class='form-horizontal' id='reg_form'>
					<fieldset>
						<?php 	
								$complainant=$_POST['complainant'];
								$respondent=$_POST['respondent'];
								$_SESSION['respondent']=$respondent;
								$_SESSION['complainant']=$complainant;
								
								
								
								//when a company lodge against another company
								if($complainant=='Company' and $respondent=='Company'){
									include"includes/Company_complainant.php";
									include"includes/company_respondent.php";
									include"includes/complaint_details.php";
								//when a company lodge against a person
								}elseif($complainant=='Company' and $respondent=='Person'){
									include"includes/Company_complainant.php";
									include"includes/personal_respondent.php";
									include"includes/complaint_details.php";
								//when a person lodge against a company
								}elseif($complainant=='Person' and $respondent=='Company'){
									include"includes/Personal_complainant.php";
									include"includes/company_respondent.php";
									include"includes/complaint_details.php";
								//when a company lodge against a Group
								}elseif($complainant=='Company' and $respondent=='Group'){
									include"includes/Company_complainant.php";
									include"includes/Group_respondent.php";
									include"includes/complaint_details.php";
								//when a Group lodge against a Company
								}elseif($complainant=='Group' and $respondent=='Company'){
									include"includes/Group_complainant.php";
									include"includes/company_respondent.php";
									include"includes/complaint_details.php";
								//when a Group lodge against a Group
								}elseif($complainant=='Group' and $respondent=='Group'){
									include"includes/Group_complainant.php";
									include"includes/Group_respondent.php";
									include"includes/complaint_details.php";
								//when a Group lodge against a person
								}elseif($complainant=='Group' and $respondent=='Person'){
									include"includes/Group_complainant.php";
									include"includes/personal_respondent.php";
									include"includes/complaint_details.php";
								//when a Person lodge against a Group
								}elseif($complainant=='Person' and $respondent=='Group'){
									include"includes/personal_complainant.php";
									include"includes/Group_respondent.php";
									include"includes/complaint_details.php";
								//when a Person lodge against a person
								}elseif($complainant=='Person' and $respondent=='Person'){
									include"includes/personal_complainant.php";
									include"includes/personal_respondent.php";
									include"includes/complaint_details.php";
								}
						?>
						<div class='form-group'>
							<label class='col-md-4 control-label'></label>
							<div class='col-md-4'>
								<button type='submit' class='btn btn-warning'>save<span class='glyphicon glyphicon-save'></span>
								</button>
							</div>
						</div>
					</fieldset>
				</form>
      </div>
    </div>	
<?php include"../footer.php";?>
	
	</body>

</html>