<!DOCTYPE html>
<?php session_start(); 
	date_default_timezone_set('Africa/Harare');
			$now=date('Y-m-s');
	include"includes/connect.php";
			
	$complainant=$_SESSION['complainant'];
	$respondent=$_SESSION['respondent'];

		//when a company lodge against another company
		if($complainant=='Company' and $respondent=='Company'){
			$fname=$_POST['cc_fname'];
			$cc_ctype=$_POST['cc_ctype'];
			$address=$_POST['cc_address'];
			$cname=$_POST['cr_fname'];
			$cr_ctype=$_POST['cr_ctype'];
			$caddress=$_POST['cr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id1','$fname','$cc_ctype','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id2','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a company lodge against a person
		}elseif($complainant=='Company' and $respondent=='Person'){
			$fname=$_POST['pr_fname'];
			$dob=$_POST['pr_dob'];
			$gender=$_POST['pr_gender'];
			$address=$_POST['pr_address'];
			$cname=$_POST['cr_fname'];
			$cr_ctype=$_POST['cr_ctype'];
			$caddress=$_POST['cr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO personal(PersonalID, Name, Gender, DoB, Address) VALUES('$id2','$fname','$gender','$dob','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id1','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a person lodge against a company
		}elseif($complainant=='Person' and $respondent=='Company'){
			$fname=$_POST['pc_fname'];
			$dob=$_POST['pc_dob'];
			$gender=$_POST['pc_gender'];
			$address=$_POST['pc_address'];
			$cname=$_POST['cr_fname'];
			$cr_ctype=$_POST['cr_ctype'];
			$caddress=$_POST['cr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO personal(PersonalID, Name, Gender, DoB, Address) VALUES('$id1','$fname','$gender','$dob','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id2','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a company lodge against a Group
		}elseif($complainant=='Company' and $respondent=='Group'){
			$fname=$_POST['cc_fname'];
			$cc_ctype=$_POST['cc_ctype'];
			$address=$_POST['cc_address'];
			$cname=$_POST['gr_fname'];
			$cr_ctype=$_POST['gr_ctype'];
			$caddress=$_POST['gr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id1','$fname','$cc_ctype','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id2','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a Group lodge against a Company
		}elseif($complainant=='Group' and $respondent=='Company'){
			$fname=$_POST['gc_fname'];
			$cc_ctype=$_POST['gc_ctype'];
			$address=$_POST['gc_address'];
			$cname=$_POST['cr_fname'];
			$cr_ctype=$_POST['cr_ctype'];
			$caddress=$_POST['cr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id1','$fname','$cc_ctype','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id2','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a Group lodge against a Group
		}elseif($complainant=='Group' and $respondent=='Group'){
			$fname=$_POST['gc_fname'];
			$cc_ctype=$_POST['gc_ctype'];
			$address=$_POST['gc_address'];
			$cname=$_POST['gr_fname'];
			$cr_ctype=$_POST['gr_ctype'];
			$caddress=$_POST['gr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id1','$fname','$cc_ctype','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id2','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a Group lodge against a person
		}elseif($complainant=='Group' and $respondent=='Person'){
			$fname=$_POST['pr_fname'];
			$dob=$_POST['pr_dob'];
			$gender=$_POST['pr_gender'];
			$address=$_POST['pr_address'];
			$cname=$_POST['gc_fname'];
			$cr_ctype=$_POST['gc_ctype'];
			$caddress=$_POST['gc_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO personal(PersonalID, Name, Gender, DoB, Address) VALUES('$id2','$fname','$gender','$dob','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id1','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a Person lodge against a Group
		}elseif($complainant=='Person' and $respondent=='Group'){
			$fname=$_POST['pc_fname'];
			$dob=$_POST['pc_dob'];
			$gender=$_POST['pc_gender'];
			$address=$_POST['pc_address'];
			$cname=$_POST['gr_fname'];
			$cr_ctype=$_POST['gr_ctype'];
			$caddress=$_POST['gr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO personal(PersonalID, Name, Gender, DoB, Address) VALUES('$id1','$fname','$gender','$dob','$address')";
			$query4="INSERT INTO company(PartyID, CompanyName, CompanyCat, Address) VALUES('$id2','$cname','$cr_ctype','$caddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		//when a Person lodge against a person
		}elseif($complainant=='Person' and $respondent=='Person'){
			$fname=$_POST['pc_fname'];
			$dob=$_POST['pc_dob'];
			$gender=$_POST['pc_gender'];
			$address=$_POST['pc_address'];
			$fpname=$_POST['pr_fname'];
			$pdob=$_POST['pr_dob'];
			$pgender=$_POST['pr_gender'];
			$paddress=$_POST['pr_address'];
			$received=$_POST['received'];
			$code=$_POST['case'];
			$dispute=$_POST['dispute'];
			$rights=$_POST['rights'];
			$district=$_POST['district'];
			$occurred=$_POST['occurrence'];
			$actaken=$_POST['taken'];
			$status=$_POST['status'];
			$reco=$_POST['reco'];
			
			date_default_timezone_set('Africa/Harare');
			$plus=date('H:i:s-Y-m-s');
			$id1=$plus.'comp';
			$id2=$plus.'res';
			
			$query1="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id1','Complainant','$complainant')";
			$result1=mysqli_query($dbc,$query1) or die(mysqli_error($dbc));
			$query2="INSERT INTO party(CaseNO, PartyID, PatyTitle, PartyCart) VALUES('$code','$id2','Respondent','$respondent')";
			$query3="INSERT INTO personal(PersonalID, Name, Gender, DoB, Address) VALUES('$id1','$fname','$gender','$dob','$address')";
			$query4="INSERT INTO personal(PersonalID, Name, Gender, DoB, Address) VALUES('$id2','$fpname','$pgender','$pdob','$paddress')";
			$query5="INSERT INTO `case`(CaseNO, Received, Dispute, Rights, District, Occured, ActionTaken, CurrentStatus, Recommendation) VALUES('$code','$received','$dispute','$rights','$district','$occurred','$actaken','$status','$reco')";

			$result2=mysqli_query($dbc,$query2) or die(mysqli_error($dbc));
			$result3=mysqli_query($dbc,$query3) or die(mysqli_error($dbc));
			$result4=mysqli_query($dbc,$query4) or die(mysqli_error($dbc));
			$result5=mysqli_query($dbc,$query5) or die(mysqli_error($dbc));
		}								
		
								include"case_view.php";
?>
