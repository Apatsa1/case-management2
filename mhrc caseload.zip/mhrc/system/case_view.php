<html lang='en'>

<?php include"header.php"; 
include"includes/connect.php";
?><br/><br/><br/><br/><br/>
	<div class="container" role="main">
      <div class="row">
	  <?php include"includes/sumup_queries.php";?>
          <table class='table pagination'>
					<tr>
						<th>Date Complaint Receive</th>
						<th>Case No</th>
						<th>Complainant</th>
						<th>Respondent</th>
						<th>Nature of Dispute</th>
						<th>Rights Involved</th>
						<th>District of dispute</th>
						<th>Date Dispute occurred</th>
						<th>action taken</th>
						<th>current status</th>
						<th>recommendation</th>
					</tr>
					<?php
					$query6="select * from `case`";
					$result6=mysqli_query($dbc,$query6) or die(mysqli_error($dbc));
					While($row=mysqli_fetch_array($result6)){
						$case=$row['CaseNO'];
						$received=$row['Received'];
						$dispute=$row['Dispute'];
						$rights=$row['Rights'];
						$district=$row['District'];
						$occurred=$row['Occured'];
						$actaken=$row['ActionTaken'];
						$status=$row['CurrentStatus'];
						$reco=$row['Recommendation'];
						
							echo"<tr>".
									"<td>".$received."</td>".
									"<td>"."<a href='case_summary.php?id=".$case."'>".$case."</a>"."</td>";
									$query7="select * from party where CaseNO='$case' and PatyTitle='Complainant'";
									$result7=mysqli_query($dbc,$query7) or die(mysqli_error($dbc));
									
									while($myrow=mysqli_fetch_array($result7)){
										$pcase=$myrow['CaseNO'];
										$partyID=$myrow['PartyID'];
										$partytitle=$myrow['PatyTitle'];
										$partycat=$myrow['PartyCart'];
										
										if($partycat=='Person'){
											$query8="select * from personal where PersonalID='$partyID'";
											$result8=mysqli_query($dbc,$query8) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result8)){
												$fullname=$myrow1['Name'];
												$gender=$myrow1['Gender'];
												$dob=$myrow1['DoB'];
												$address=$myrow1['Address'];
												$age=(date('Y',strtotime(date('Y')))-date('Y',strtotime($dob)));
												
												echo "<td>"
														.$fullname."<br/>"
														.$gender."<br/>"
														."Aged ".$age."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}elseif($partycat=='Company'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<td>"
														.$fullname."<br/>"
														.$cat."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}elseif($partycat=='Group'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<td>"
														.$fullname."<br/>"
														.$cat."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}
									}
									
									$query10="select * from party where CaseNO='$case' and PatyTitle='Respondent'";
									$result10=mysqli_query($dbc,$query10) or die(mysqli_error($dbc));
									while($myrow=mysqli_fetch_array($result10)){
										$pcase=$myrow['CaseNO'];
										$partyID=$myrow['PartyID'];
										$partytitle=$myrow['PatyTitle'];
										$partycat=$myrow['PartyCart'];
										
										if($partycat=='Person'){
											$query8="select * from personal where PersonalID='$partyID'";
											$result8=mysqli_query($dbc,$query8) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result8)){
												$fullname=$myrow1['Name'];
												$gender=$myrow1['Gender'];
												$dob=$myrow1['DoB'];
												$address=$myrow1['Address'];
												$age=$now-$dob;
												
												echo "<td>"
														.$fullname."<br/>"
														.$gender."<br/>"
														."Aged ".$now."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}elseif($partycat=='Company'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<td>"
														.$fullname."<br/>"
														.$cat."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}elseif($partycat=='Group'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<td>"
														.$fullname."<br/>"
														.$cat."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}
									}
									echo"<td>".$dispute."</td>".
										"<td>".$rights."</td>".
										"<td>".$district."</td>".
										"<td>".$occurred."</td>".
										"<td>".$actaken."</td>".
										"<td>".$status."</td>".
										"<td>".$reco."</td>".
									
								"</tr>";
					}
					?>
				</table>
      </div>
    </div>	
<?php include"../footer.php";?>
	
	</body>

</html>