<?php
	$dbc=mysqli_connect("localhost", "root","","masterdatabase") or die("Host Unreachable");
?>