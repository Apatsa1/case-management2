<legend>COMPLAINT DETAILS</legend>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Full Name</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
									<input name='gc_fname' class='form-control' type='text' placeholder='Complainant full name'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Company type</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='radio'><span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
									<label><input name='gc_ctype' type='radio' <?php if (isset($gc_ctype) && $gc_ctype=="Finance") echo "checked";?> value='Finance'>Finance</label>
									<label><input name='gc_ctype' type='radio' <?php if (isset($gc_ctype) && $gc_ctype=="Agriculture") echo "checked";?> value='Agriculture'>Agriculture</label>
									<label><input name='gc_ctype' type='radio' <?php if (isset($gc_ctype) && $gc_ctype=="Community") echo "checked";?> value='Community'>Community</label>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Address</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='gc_address' class='form-control' type='text' placeholder='postal address, phone and email'></textarea>
								</div>
							</div>
						</div>