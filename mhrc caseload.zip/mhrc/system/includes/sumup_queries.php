<?php 
$sql1="select count(*) from `case`";
$sql2="select count(*) from `case` where CurrentStatus='stale'";
$sql3="select count(*) from `case` where CurrentStatus='closed'";

$result01=mysqli_query($dbc,$sql1);
while($jrow=mysqli_fetch_array($result01)){
	$total=$jrow[0];
	echo "<p>"."out of "."<b>".$total."</b>"." reported to malawi human rights commission ";
}

$result02=mysqli_query($dbc,$sql2);
while($jrow=mysqli_fetch_array($result02)){
	$totalstale=$jrow[0];
	echo " "."<b>".$totalstale." are still open"."</b>"." and "; 
}

$result03=mysqli_query($dbc,$sql3);
while($jrow=mysqli_fetch_array($result03)){
	$totalclosed=$jrow[0];
	echo " "."<b>".$totalclosed." are closed."."</b>";
}
?>