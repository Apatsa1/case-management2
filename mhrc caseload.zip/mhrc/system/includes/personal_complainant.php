<legend>COMPLAINANT DETAILS</legend>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Full Name</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
									<input name='pc_fname' class='form-control' type='text' placeholder='Complainant full name'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Date of birth</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-time'></i></span>
									<input name='pc_dob' class='form-control' type='date' placeholder='date of birth'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Gender</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='radio'><span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
									<label><input name='pc_gender' type='radio'<?php if (isset($gender) && $gender=="Male") echo "checked";?> value='Male'>Male</label>
									<label><input name='pc_gender' type='radio'<?php if (isset($gender) && $gender=="Female") echo "checked";?> value='Female'>Female</label>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Address</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='pc_address' class='form-control' type='text' placeholder='postal address, phone and email'></textarea>
								</div>
							</div>
						</div>