<legend>IDENTIFY COMPLAINT PARTIES</legend>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Complainant Type</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<select name='complainant' class='form-control'>
										<option>Person</option>
										<option>Group</option>
										<option>Company</option>
									</select>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Respondent Type</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<select name='respondent' class='form-control'>
										<option>Person</option>
										<option>Group</option>
										<option>Company</option>
									</select>
								</div>
							</div>
						</div>