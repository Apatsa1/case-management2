<legend>COMPLAINT DETAILS</legend>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Full Name</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
									<input name='cc_fname' class='form-control' type='text' placeholder='Complainant full name'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Company type</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='radio'><span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
									<label><input name='cc_ctype' type='radio'<?php if (isset($cc_ctype) && $cc_ctype=="Government") echo "checked";?> value='Government'>Government</label>
									<label><input name='cc_ctype' type='radio'<?php if (isset($cc_ctype) && $cc_ctype=="NGO") echo "checked";?> value='NGO'>NGO</label>
									<label><input name='cc_ctype' type='radio'<?php if (isset($cc_ctype) && $cc_ctype=="Commercial") echo "checked";?> value='Commercial'>Commercial</label>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Address</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='cc_address' class='form-control' type='text' placeholder='postal address, phone and email'></textarea>
								</div>
							</div>
						</div>