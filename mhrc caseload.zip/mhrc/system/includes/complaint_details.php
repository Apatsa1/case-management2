						<legend>COMPLAINT DETAILS</legend>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Case Number</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<input name='case' class='form-control' type='text' placeholder='case number'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Date Complaint Received</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-calendar'></i></span>
									<input name='received' class='form-control' type='date' placeholder='date Complaint Received'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Nature of Dispute</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='dispute' class='form-control' type='text' placeholder='nature of dispute or case statement'></textarea>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Rights Involved</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='rights' class='form-control' type='text' placeholder='rights involved'></textarea>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>District dispute occurred</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<select name='district' class='form-control'>
										<option>Balaka</option>
										<option>Blantyre</option>
										<option>Chikwawa</option>
										<option>Chitipa</option>
										<option>Chiradzulu</option>
										<option>Dedza</option>
										<option>Dowa</option>
										<option>Kasungu</option>
										<option>Karonga</option>
										<option>Likoma</option>
										<option>Lilongwe</option>
										<option>Mchinji</option>
										<option>Machinga</option>
										<option>Mangochi</option>
										<option>Mulanje</option>
										<option>Mwanza</option>
										<option>Mzimba</option>
										<option>Nkhotakota</option>
										<option>Ntcheu</option>
										<option>Ntchisi</option>
										<option>Nkhata Bay</option>
										<option>Nsanje</option>
										<option>Neno</option>
										<option>Phalombe</option>
										<option>Rumphi</option>
										<option>Salima</option>
										<option>Thyolo</option>
										<option>Zomba</option>
										
									</select>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Date dispute occurred</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-calendar'></i></span>
									<input name='occurrence' class='form-control' type='date' placeholder='date dispute occurred'>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>Action Taken</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='taken' class='form-control' type='text' placeholder='action taken'></textarea>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>current status</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<select name='status' class='form-control'>
										<option>stale</option>
										<option>closed</option>
									</select>
								</div>
							</div>
						</div>
						<div class='form-group'>
							<label class='col-md-4 control-label'>recommendation</label>
							<div class='col-md-6 inputGroupContainer'>
								<div class='input-group'><span class='input-group-addon'><i class='glyphicon glyphicon-edit'></i></span>
									<textarea name='reco' class='form-control' type='text' placeholder='action taken'></textarea>
								</div>
							</div>
						</div>