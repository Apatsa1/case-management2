<html lang='en'>

<?php include"header.php"; 
include"includes/connect.php";
$comp=$_GET['id'];
?><br/><br/><br/><br/><br/>
	<div class="container" role="main">
      <div class="row">
					
					<?php
					echo "<h2>".$comp." CASE REPORT"."</h2>";
					$query6="select * from `case` where CaseNO='$comp'";
					$result6=mysqli_query($dbc,$query6) or die(mysqli_error($dbc));
					While($row=mysqli_fetch_array($result6)){
						$case=$row['CaseNO'];
						$received=$row['Received'];
						$dispute=$row['Dispute'];
						$rights=$row['Rights'];
						$district=$row['District'];
						$occurred=$row['Occured'];
						$actaken=$row['ActionTaken'];
						$status=$row['CurrentStatus'];
						$reco=$row['Recommendation'];
						
							echo"<h4>"."introduction"."</h4>".
									"<p>"."The case was received on ".$received." between ";
									$query7="select * from party where CaseNO='$case' and PatyTitle='Complainant'";
									$result7=mysqli_query($dbc,$query7) or die(mysqli_error($dbc));
									
									while($myrow=mysqli_fetch_array($result7)){
										$pcase=$myrow['CaseNO'];
										$partyID=$myrow['PartyID'];
										$partytitle=$myrow['PatyTitle'];
										$partycat=$myrow['PartyCart'];
										
										if($partycat=='Person'){
											$query8="select * from personal where PersonalID='$partyID'";
											$result8=mysqli_query($dbc,$query8) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result8)){
												$fullname=$myrow1['Name'];
												$gender=$myrow1['Gender'];
												$dob=$myrow1['DoB'];
												$address=$myrow1['Address'];
												$age=(date('Y',strtotime(date('Y')))-date('Y',strtotime($dob)));
												
												echo "<b>".$fullname." (".$gender.")"
														."Aged ".$age." and "
														.$address."</b>"." as complainant Address. and ";
												}
										}elseif($partycat=='Company'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<b>".$fullname." belong to ".$cat." sector"
														."with Address ".$address
													."</b>";
												}
										}elseif($partycat=='Group'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<td>"
														.$fullname."<br/>"
														.$cat."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}
									}
									
									$query10="select * from party where CaseNO='$case' and PatyTitle='Respondent'";
									$result10=mysqli_query($dbc,$query10) or die(mysqli_error($dbc));
									while($myrow=mysqli_fetch_array($result10)){
										$pcase=$myrow['CaseNO'];
										$partyID=$myrow['PartyID'];
										$partytitle=$myrow['PatyTitle'];
										$partycat=$myrow['PartyCart'];
										
										if($partycat=='Person'){
											$query8="select * from personal where PersonalID='$partyID'";
											$result8=mysqli_query($dbc,$query8) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result8)){
												$fullname=$myrow1['Name'];
												$gender=$myrow1['Gender'];
												$dob=$myrow1['DoB'];
												$address=$myrow1['Address'];
												$age=$now-$dob;
												
												echo "<td>"
														.$fullname."<br/>"
														.$gender."<br/>"
														."Aged ".$now."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}elseif($partycat=='Company'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<b>".$fullname." belong to ".$cat." sector "
														."with Address ".$address
													."</b>"." the case that occurred on ".$occurred." in ".$district."</p>";
												}
										}elseif($partycat=='Group'){
											$query9="select * from company where PartyID='$partyID'";
											$result9=mysqli_query($dbc,$query9) or die(mysqli_error($dbc));
											while($myrow1=mysqli_fetch_array($result9)){
												$fullname=$myrow1['CompanyName'];
												$cat=$myrow1['CompanyCat'];
												$address=$myrow1['Address'];
												
												echo "<td>"
														.$fullname."<br/>"
														.$cat."<br/>"
														."Address".$address."<br/>"
													."</td>";
												}
										}
									}
									echo"<h4>"."Complainant Statement"."</h4>".
										"<p>".$dispute."</p>".
										"<h4>"."This case violated the following rights"."</h4>".
										"<p>".$rights."</p>".
										"<h4>"."The following action where taken in response to the complainant"."</h4>".
										"<p>".$actaken."</p>".
										"<p>"."Currently the case is "."<b>".$status."</b>"."</p>".
										"<p>"."The malawi human rights recommend ".$reco."</p>";
					}
					?>
      </div>
    </div>	
<?php include"../footer.php";?>
	
	</body>

</html>