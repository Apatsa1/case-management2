<!DOCTYPE html>

<html lang='en'>

<?php include"header.php"; ?>
	<div class="container" role="main">
      <div class="row">
          <form action='system/complaint_form.php' method='POST' class='form-horizontal' id='reg_form'>
					<fieldset>
						<?php 	include"system/includes/define.php";
						?>
						<div class='form-group'>
							<label class='col-md-4 control-label'></label>
							<div class='col-md-4'>
								<button type='submit' class='btn btn-warning'>submit<span class='glyphicon glyphicon-search'></span>
								</button>
							</div>
						</div>
					</fieldset>
				</form>
      </div>
    </div>	
<?php include"footer.php";?>
	
	</body>

</html>