		<footer class='container-fluid text-center'>
			<i class="fa fa-copyright" aria-hidden="true">MALAWI HUMAN RIGHTS COMMISSION </i>
		</footer>
	
	</body>

</html>