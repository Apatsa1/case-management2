	<head>
	
		<title>MHRC|CaseLoad</title>
		<meta charset='utf-8'>
		<meta name='viewport' content='width=device-width, initial-scale=1'>
		<link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
		<link rel='stylesheet' href='bootstrap/css/font-awesome-4.7.0/css/font-awesome.min.css'>
		<link rel='icon' href='images/mhrc.png'>
		<script src='bootstrap/js/jquery.min.js'></script>
		<script src='bootstrap/js/bootstrap.min.js'></script>
		<style>
			.navbar{
				margin-bottom: 0;
				border-radius: 0;
				background-color: #bea167;
				color: #fff;
				/*padding: 1% 0;*/
				font-size: 1.2em;
				border: 0;
			}
			
			.navbar-brand{
				float: left;
				min-height: 55px;
				padding: 0 15px 5px;
			}
			
			.navbar-brand img{
				height: 100%;
			}
			
			.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus, .navbar-inverse .navbar-nav .active a:hover{
				color: #fff;
				background-color: #83786a;
			}
			
			.navbar-inverse .navbar-nav li a{
				color: #d3162c;
			}
			
			.carousel-caption{
				top: 50%;
				transform: translateY(-50%);
				text-transform: uppercase;
			}
			
			.btn{
				font-size: 18px;
				color: green;
				padding: 12px 22px;
				background: 2px solid #fff;
			}
			
			.container{
				/*margin: 4% auto;*/
				border-bottom: 5px solid #83786a;
				border-top: 5px solid #83786a;
				padding: 1%;
			}
			
			.container h2{
				text-align: left;
				padding: 1%;
			}
			.container h4{
				border-bottom: 1px solid gray;
				border-top: 1px solid gray;
			}
			
			#icon{
				max-width: 200px;
				margin: 1% auto;
			}
			
			footer{
				width: 100%;
				background-color: #bea167;
				padding: 1%;
				color: #fff;
			}
			
			footer a{
				width: 100%;
				float: left;
				color: #fff;
			}
			
			@media (max-width: 600px){
				.carousel-caption{
					display: none;
				}
				
				#icon{
					max-width: 150px;
				}
				
				h2{
					font-size: 1.9em;
				}
			}
		</style>
		
		<script>
            $(function() {
                $(".dropdown").hover(
                        function() {
                            $('.dropdown-menu', this).stop(true, true).fadeIn("fast");
                            $(this).toggleClass('open');
                            $('b', this).toggleClass("caret caret-up");
                        },
                        function() {
                            $('.dropdown-menu', this).stop(true, true).fadeOut("fast");
                            $(this).toggleClass('open');
                            $('b', this).toggleClass("caret caret-up");
                        });
            });

        </script>
	
	</head>
	
	<body>
	
		<nav class='navbar navbar-inverse'>
		
			<div class='container-fluid'>
			
				<div class='navbar-header'>
			
					<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#myNavbar'>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
					</button>
					<a class='navbar-brand' href='#'><img src='images/mhrc.png'></a>
			
				</div>
				<div class='collapse navbar-collapse' id='myNavbar'>
					<ul class='nav navbar-nav navbar-right'>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">Case Records</a>
							<ul class='dropdown-menu show-on-hover'>
								<li><a href='system/closed_case.php'>View Closed Cases</a></li>
								<li><a href='system/open_case.php'>View Open Cases</a></li>
								<li><a href='system/case_view.php'>Case Summaries</a></li>
								<li><a href='#'>Case Feedback</a></li>
							</ul>
						</li>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">Complaints</a>
							<ul class='dropdown-menu show-on-hover'>
								<li><a href='index.php'>Lodge Complaint</a></li>
								<li><a href='#'>Update Complaint</a></li>
								<li><a href='#'>Close a Complaint</a></li>
							</ul>
						</li>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">Statistics</a></li>
					</ul>
				</div>
			
			</div>
		
		</nav>