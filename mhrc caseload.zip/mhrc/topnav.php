			.navbar{
				margin-bottom: 0;
				border-radius: 0;
				background-color: green;
				color: #fff;
				padding: 1% 0;
				font-size: 1.2em;
				border: 0;
			}
			
			.navbar-brand{
				float: left;
				min-height: 55px;
				padding: 0 15px 5px;
			}
			
			.navbar-brand img{
				height: 100%;
			}
			
			.navbar-inverse .navbar-nav .active a, .navbar-inverse .navbar-nav .active a:focus, .navbar-inverse .navbar-nav .active a:hover{
				color: #fff;
				background-color: green;
			}
			
			.navbar-inverse .navbar-nav li a{
				color: #D5D5D5;
			}
			
			.carousel-caption{
				top: 50%;
				transform: translateY(-50%);
				text-transform: uppercase;
			}
			
			.btn{
				font-size: 18px;
				color: green;
				padding: 12px 22px;
				background: 2px solid #fff;
			}
			
			.container{
				margin: 4% auto;
				border-bottom: 5px solid green;
				border-top: 5px solid green;
				padding: 1%;
			}
			
			.container h2{
				text-align: left;
				padding: 1%;
			}
			.container h4{
				border-bottom: 1px solid gray;
				border-top: 1px solid gray;
			}
			
			#icon{
				max-width: 200px;
				margin: 1% auto;
			}
			
			footer{
				width: 100%;
				background-color: green;
				padding: 3%;
				color: #fff;
			}
			
			footer a{
				width: 100%;
				float: left;
				color: #fff;
			}
			
			@media (max-width: 600px){
				.carousel-caption{
					display: none;
				}
				
				#icon{
					max-width: 150px;
				}
				
				h2{
					font-size: 1.9em;
				}
			}
		</style>
		
		<script>
            $(function() {
                $(".dropdown").hover(
                        function() {
                            $('.dropdown-menu', this).stop(true, true).fadeIn("fast");
                            $(this).toggleClass('open');
                            $('b', this).toggleClass("caret caret-up");
                        },
                        function() {
                            $('.dropdown-menu', this).stop(true, true).fadeOut("fast");
                            $(this).toggleClass('open');
                            $('b', this).toggleClass("caret caret-up");
                        });
            });

        </script>
	
	</head>
	
	<body>
	
		<nav class='navbar navbar-inverse'>
		
			<div class='container-fluid'>
			
				<div class='navbar-header'>
			
					<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#myNavbar'>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
						<span class='icon-bar'></span>
					</button>
					<a class='navbar-brand' href='#'><img src='../images/Ombudsman.jpg'></a>
			
				</div>
				<div class='collapse navbar-collapse' id='myNavbar'>
					<ul class='nav navbar-nav navbar-right'>
						<li class='active'><a href='#'>home</a></li>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">About Us</a>
							<ul class='dropdown-menu show-on-hover'>
								<li><a href='#'>Vision and Mission</a></li>
								<li><a href='#'>background history</a></li>
								<li><a href='#'>Service charter</a></li>
								<li><a href='#'>Leadership</a></li>
								<li><a href='#'>Organogram</a></li>
							</ul>
						</li>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">Investigations</a>
							<ul class='dropdown-menu show-on-hover'>
								<li><a href='#'>Case summary</a></li>
								<li><a href='#'>Determinations</a></li>
								<li><a href='#'>Systematic Investigations</a></li>
							</ul>
						</li>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">Documentations</a>
							<ul class='dropdown-menu show-on-hover'>
								<li><a href='#'>annual reports</a></li>
								<li><a href='#'>legislation</a></li>
								<li><a href='#'>publications</a></li>
								<li><a href='#'>speeches</a></li>
							</ul>
						</li>
						<li class='dropdown show-on-hover'><a href='#' class="dropdown-toggle  show-on-hover" data-toggle="dropdown">Media</a>
							<ul class='dropdown-menu show-on-hover'>
								<li><a href='#'>media release</a></li>
								<li><a href='#'>gallery</a></li>
							</ul>
						</li>
					</ul>
				</div>
			
			</div>
		
		</nav>